from flask import Flask, render_template, request, jsonify
from PIL import Image
import numpy as np
import joblib
import os
import cv2
import scipy.stats as stats
from skimage.feature import local_binary_pattern, graycomatrix, graycoprops
from skimage import morphology
from sklearn.preprocessing import StandardScaler

app = Flask(__name__)

# Load your SVM model
model_path = os.path.join(os.path.dirname(__file__), 'best_svm_model.pkl')
try:
    svm_model = joblib.load(model_path)
    app.logger.info("SVM model loaded successfully.")
except Exception as e:
    app.logger.error(f"Error loading model: {e}")
    svm_model = None

# Preprocessing Steps
def apply_median_filter(image, ksize=5):
    return cv2.medianBlur(image, ksize)

def convert_to_binary_otsu(image):
    _, binary_image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return binary_image

def remove_artifacts(binary_image, min_area=500):
    clean_binary_image = morphology.remove_small_objects(binary_image > 0, min_size=min_area)
    clean_binary_image = clean_binary_image.astype(np.uint8) * 255
    kernel = np.ones((5, 5), np.uint8)
    clean_binary_image = cv2.morphologyEx(clean_binary_image, cv2.MORPH_CLOSE, kernel)
    clean_binary_image = cv2.morphologyEx(clean_binary_image, cv2.MORPH_OPEN, kernel)
    return clean_binary_image

def segment_breast_area(image):
    ret, thresh = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        breast_contour = max(contours, key=cv2.contourArea)
        mask = np.zeros_like(image)
        cv2.drawContours(mask, [breast_contour], -1, 255, thickness=cv2.FILLED)
        segmented_image = cv2.bitwise_and(image, image, mask=mask)
        return segmented_image
    else:
        return image

# Feature Extraction Functions
def extract_first_order_features(image):
    pixel_values = image.flatten()
    mean = np.mean(pixel_values)
    variance = np.var(pixel_values)
    std_dev = np.std(pixel_values)
    skewness = stats.skew(pixel_values)
    kurtosis = stats.kurtosis(pixel_values)
    entropy = stats.entropy(np.histogram(pixel_values, bins=256)[0], base=2)
    return [mean, variance, std_dev, skewness, kurtosis, entropy]

def extract_glcm_features(image):
    glcm = graycomatrix(image, distances=[1], angles=[0, np.pi/4, np.pi/2, 3*np.pi/4], symmetric=True, normed=True)
    contrast = graycoprops(glcm, 'contrast').mean()
    dissimilarity = graycoprops(glcm, 'dissimilarity').mean()
    homogeneity = graycoprops(glcm, 'homogeneity').mean()
    energy = graycoprops(glcm, 'energy').mean()
    correlation = graycoprops(glcm, 'correlation').mean()
    asm = graycoprops(glcm, 'ASM').mean()
    return [contrast, dissimilarity, homogeneity, energy, correlation, asm]

def extract_lbp_features(image):
    radius = 1  # LBP radius
    n_points = 8 * radius  # Number of points to consider for LBP
    lbp = local_binary_pattern(image, n_points, radius, method='uniform')
    lbp_hist, _ = np.histogram(lbp.ravel(), bins=np.arange(0, n_points + 3), range=(0, n_points + 2))
    lbp_hist = lbp_hist.astype("float")
    lbp_hist /= (lbp_hist.sum() + 1e-7)  # Normalize the histogram
    return lbp_hist

def apply_gabor_filter(image):
    gabor_kernels = []
    ksize = 31  # Size of the filter
    for theta in np.arange(0, np.pi, np.pi / 8):
        kernel = cv2.getGaborKernel((ksize, ksize), 4.0, theta, 10.0, 0.5, 0, ktype=cv2.CV_32F)
        gabor_kernels.append(kernel)
    gabor_responses = []
    for kernel in gabor_kernels:
        filtered_img = cv2.filter2D(image, cv2.CV_8UC3, kernel)
        gabor_responses.append(filtered_img.mean())  # You can change this to other statistics (e.g., std, max)
    return gabor_responses

# Complete Preprocessing and Feature Extraction
def preprocess_image(image):
    # Convert to grayscale if not already
    image = image.convert("L")
    
    # Convert to numpy array
    image = np.array(image)

    # Apply preprocessing steps
    median_filtered_image = apply_median_filter(image)
    segmented_image = segment_breast_area(median_filtered_image)
    binary_image = convert_to_binary_otsu(segmented_image)
    cleaned_image = remove_artifacts(binary_image)

    # Extract features from the preprocessed image
    first_order_features = extract_first_order_features(cleaned_image)
    glcm_features = extract_glcm_features(cleaned_image)
    lbp_features = extract_lbp_features(cleaned_image)
    gabor_features = apply_gabor_filter(cleaned_image)

    # Combine all features into a single feature vector
    features = first_order_features + glcm_features + list(lbp_features) + gabor_features

    # Normalize features (assuming you used the same scaler in training)
    scaler = StandardScaler()
    features = scaler.fit_transform(np.array(features).reshape(1, -1))  # Scale and reshape

    return features

# Define routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        app.logger.warning("No file part in the request.")
        return jsonify({'error': 'No file part in the request.'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        app.logger.warning("No file selected for uploading.")
        return jsonify({'error': 'No file selected for uploading.'}), 400
    
    try:
        image = Image.open(file)
    except Exception as e:
        app.logger.error(f"Error opening image: {e}")
        return jsonify({'error': 'Invalid image file.'}), 400
    
    try:
        processed_image = preprocess_image(image)
        app.logger.info(f"Processed image shape: {processed_image.shape}")
    except Exception as e:
        app.logger.error(f"Error preprocessing image: {e}")
        return jsonify({'error': 'Error preprocessing image.'}), 500
    
    if svm_model is None:
        app.logger.error("SVM model is not loaded.")
        return jsonify({'error': 'Model not loaded.'}), 500
    
    try:
        prediction = svm_model.predict(processed_image)
        decision_function = svm_model.decision_function(processed_image)
        app.logger.info(f"Prediction made: {prediction[0]}, Decision function: {decision_function[0]}")
        
        result = "malignant" if prediction[0] == 1 else "benign"
        return jsonify({'result': result})
    except Exception as e:
        app.logger.error(f"Error making prediction: {e}")
        return jsonify({'error': f"Error making prediction: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True)
